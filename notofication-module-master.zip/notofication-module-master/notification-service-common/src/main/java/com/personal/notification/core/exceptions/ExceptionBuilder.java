package com.personal.notification.core.exceptions;

/**
 * exception builder
 * @author dvsnk
 *
 */
public class ExceptionBuilder {

	
	/**
	 * builds excpetion
	 */
	public void build() {
		
	}
}
