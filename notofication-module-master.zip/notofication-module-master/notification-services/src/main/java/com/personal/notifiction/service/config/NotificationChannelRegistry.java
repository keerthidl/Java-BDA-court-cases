package com.personal.notifiction.service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.personal.notifiction.service.controller.PingServiceController;

/**
 * 
 * @author dvsnk
 *
 */
@Configuration
public class NotificationChannelRegistry {
	
	/**
	 * email service
	 */
	//@Bean(name="pingService")
	//public PingService getEmailService() {
		//return new PingService();
	//}
	
	/**
	 * email service
	 */
	//@Bean(name="smsService")
	/**public PingService getSMSService() {
		return new PingService();
	}
	**/
	
	/**
	 * email service
	 */
	//@Bean(name="pushService")
	/**public PingService getPushService() {
		return new PingService();
	}**/

}
