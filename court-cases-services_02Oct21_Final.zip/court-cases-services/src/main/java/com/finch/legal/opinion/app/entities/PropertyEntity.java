package com.finch.legal.opinion.app.entities;

import javax.persistence.Column;
/**
 * department entity
 * @author finch
 *
 */
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "property")
public class PropertyEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	/** id **/
	private int id;
	
	@Column(name = "address_id")
	/** employee id **/
	private int address_id;
	
	
	@Column(name = "prop_type")
	/** employee id **/
	private String prop_type;
	
	@Column(name = "prop_id")
	/** employee id **/
	private String prop_id;
	
	@Column(name = "extent")
	/** employee id **/
	private String extent;
	

	@Column(name = "north")
	/** employee id **/
	private String north;
	 
	@Column(name = "south")
	/** employee id **/
	private String south;
	
	@Column(name = "east")
	/** employee id **/
	private String east;
	
	@Column(name = "west")
	/** employee id **/
	private String west;
	
	@Column(name = "village_name")
	/** employee id **/
	private String village_name;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the address_id
	 */
	public int getAddress_id() {
		return address_id;
	}

	/**
	 * @param address_id the address_id to set
	 */
	public void setAddress_id(int address_id) {
		this.address_id = address_id;
	}

	/**
	 * @return the prop_type
	 */
	public String getProp_type() {
		return prop_type;
	}

	/**
	 * @param prop_type the prop_type to set
	 */
	public void setProp_type(String prop_type) {
		this.prop_type = prop_type;
	}

	/**
	 * @return the prop_id
	 */
	public String getProp_id() {
		return prop_id;
	}

	/**
	 * @param prop_id the prop_id to set
	 */
	public void setProp_id(String prop_id) {
		this.prop_id = prop_id;
	}

	/**
	 * @return the extent
	 */
	public String getExtent() {
		return extent;
	}

	/**
	 * @param extent the extent to set
	 */
	public void setExtent(String extent) {
		this.extent = extent;
	}

	/**
	 * @return the north
	 */
	public String getNorth() {
		return north;
	}

	/**
	 * @param north the north to set
	 */
	public void setNorth(String north) {
		this.north = north;
	}

	/**
	 * @return the south
	 */
	public String getSouth() {
		return south;
	}

	/**
	 * @param south the south to set
	 */
	public void setSouth(String south) {
		this.south = south;
	}

	/**
	 * @return the east
	 */
	public String getEast() {
		return east;
	}

	/**
	 * @param east the east to set
	 */
	public void setEast(String east) {
		this.east = east;
	}

	/**
	 * @return the west
	 */
	public String getWest() {
		return west;
	}

	/**
	 * @param west the west to set
	 */
	public void setWest(String west) {
		this.west = west;
	}

	/**
	 * @return the village_name
	 */
	public String getVillage_name() {
		return village_name;
	}

	/**
	 * @param village_name the village_name to set
	 */
	public void setVillage_name(String village_name) {
		this.village_name = village_name;
	}
	
	
}

