package com.finch.legal.opinion.app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.finch.legal.opinion.app.entities.AdvocatesEntity;
import com.finch.legal.opinion.app.entities.PropertyAddressEntity;



public interface PropertyAddressRepository extends JpaRepository<PropertyAddressEntity, Integer> {
	
	/** by name **/
	PropertyAddressEntity findById(int id);
	
	/** by name **/
	@Query(value="SELECT * FROM address  WHERE village_name=?1",nativeQuery = true)
	PropertyAddressEntity findByName(String name);
}
