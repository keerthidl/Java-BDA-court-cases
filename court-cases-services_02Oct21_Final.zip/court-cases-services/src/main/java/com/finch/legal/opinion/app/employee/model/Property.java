package com.finch.legal.opinion.app.employee.model;

/**
 * property details
 * @author 91948
 *
 */
public class Property {
	
	/** prop type **/
	private String prop_type ="";
	
	/** prop_id type **/
	private String prop_id="";
	/** prop_id type **/
	private String  village_name="";
	/** prop_id type **/
	private String extent="";
	/** prop_id type **/
	private String east="";
	/** prop_id type **/
	private String west="";
	/** prop_id type **/
	private String north="";
	/** prop_id type **/
	private String south="";
	/**
	 * @return the prop_type
	 */
	public String getProp_type() {
		return prop_type;
	}
	/**
	 * @param prop_type the prop_type to set
	 */
	public void setProp_type(String prop_type) {
		this.prop_type = prop_type;
	}
	/**
	 * @return the prop_id
	 */
	public String getProp_id() {
		return prop_id;
	}
	/**
	 * @param prop_id the prop_id to set
	 */
	public void setProp_id(String prop_id) {
		this.prop_id = prop_id;
	}
	/**
	 * @return the village_name
	 */
	public String getVillage_name() {
		return village_name;
	}
	/**
	 * @param village_name the village_name to set
	 */
	public void setVillage_name(String village_name) {
		this.village_name = village_name;
	}
	/**
	 * @return the extent
	 */
	public String getExtent() {
		return extent;
	}
	/**
	 * @param extent the extent to set
	 */
	public void setExtent(String extent) {
		this.extent = extent;
	}
	/**
	 * @return the east
	 */
	public String getEast() {
		return east;
	}
	/**
	 * @param east the east to set
	 */
	public void setEast(String east) {
		this.east = east;
	}
	/**
	 * @return the west
	 */
	public String getWest() {
		return west;
	}
	/**
	 * @param west the west to set
	 */
	public void setWest(String west) {
		this.west = west;
	}
	/**
	 * @return the north
	 */
	public String getNorth() {
		return north;
	}
	/**
	 * @param north the north to set
	 */
	public void setNorth(String north) {
		this.north = north;
	}
	/**
	 * @return the south
	 */
	public String getSouth() {
		return south;
	}
	/**
	 * @param south the south to set
	 */
	public void setSouth(String south) {
		this.south = south;
	}
	
}
