package com.finch.legal.opinion.app.employee.model;

/**
 * 
 * @author 91948
 *
 */
public class Location {
	
	/** village name **/
	private String village_name="";
	
	/** hoblie **/
	private String hobli="";
	
	/** thaluk **/
	private String thaluk="";
	
	/** zone **/
	private String zone="";
	
	/** district **/
	private String district="";
	
	/** remarks **/
	private String remarks="";

	/**
	 * @return the village_name
	 */
	public String getVillage_name() {
		return village_name;
	}

	/**
	 * @param village_name the village_name to set
	 */
	public void setVillage_name(String village_name) {
		this.village_name = village_name;
	}

	/**
	 * @return the hobli
	 */
	public String getHobli() {
		return hobli;
	}

	/**
	 * @param hobli the hobli to set
	 */
	public void setHobli(String hobli) {
		this.hobli = hobli;
	}

	/**
	 * @return the thaluk
	 */
	public String getThaluk() {
		return thaluk;
	}

	/**
	 * @param thaluk the thaluk to set
	 */
	public void setThaluk(String thaluk) {
		this.thaluk = thaluk;
	}

	/**
	 * @return the zone
	 */
	public String getZone() {
		return zone;
	}

	/**
	 * @param zone the zone to set
	 */
	public void setZone(String zone) {
		this.zone = zone;
	}

	/**
	 * @return the district
	 */
	public String getDistrict() {
		return district;
	}

	/**
	 * @param district the district to set
	 */
	public void setDistrict(String district) {
		this.district = district;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
