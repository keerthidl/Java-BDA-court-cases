package com.finch.legal.opinion.app.employee.model;

import java.util.ArrayList;
import java.util.List;

/**
 * result
 * @author 91948
 *
 */
public class ReadAllCasesResponse {
	
	/** status **/
	private String status="200";
	
	/** status **/
	private String message="";

	/** list **/
	private List<CourtCaseDetailsModel> result=new ArrayList();
	
	/**
	 * default constructor
	 */
	public ReadAllCasesResponse(){
	
	}

	/**
	 * @return the result
	 */
	public List<CourtCaseDetailsModel> getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(List<CourtCaseDetailsModel> result) {
		this.result = result;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
