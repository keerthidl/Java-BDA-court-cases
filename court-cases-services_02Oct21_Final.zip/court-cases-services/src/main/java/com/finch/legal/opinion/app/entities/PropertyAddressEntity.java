package com.finch.legal.opinion.app.entities;

import javax.persistence.Column;
/**
 * department entity
 * @author finch
 *
 */
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "address")
public class PropertyAddressEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	/** id **/
	private int id;
	
	@Column(name = "village_name")
	/** employee id **/
	private String village_name;
	@Column(name = "hobli")
	/** employee id **/
	private String hobli;
	
	@Column(name = "taluk")
	/** employee id **/
	private String taluk;
	

	@Column(name = "district")
	/** employee id **/
	private String district;
	 
	@Column(name = "zone")
	/** employee id **/
	private String zone;
	
	@Column(name = "address_remarks")
	/** employee id **/
	private String address_remarks;

	

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the village_name
	 */
	public String getVillage_name() {
		return village_name;
	}

	/**
	 * @param village_name the village_name to set
	 */
	public void setVillage_name(String village_name) {
		this.village_name = village_name;
	}

	/**
	 * @return the hobli
	 */
	public String getHobli() {
		return hobli;
	}

	/**
	 * @param hobli the hobli to set
	 */
	public void setHobli(String hobli) {
		this.hobli = hobli;
	}

	/**
	 * @return the taluk
	 */
	public String getTaluk() {
		return taluk;
	}

	/**
	 * @param taluk the taluk to set
	 */
	public void setTaluk(String taluk) {
		this.taluk = taluk;
	}

	/**
	 * @return the district
	 */
	public String getDistrict() {
		return district;
	}

	/**
	 * @param district the district to set
	 */
	public void setDistrict(String district) {
		this.district = district;
	}

	/**
	 * @return the zone
	 */
	public String getZone() {
		return zone;
	}

	/**
	 * @param zone the zone to set
	 */
	public void setZone(String zone) {
		this.zone = zone;
	}

	/**
	 * @return the address_remarks
	 */
	public String getAddress_remarks() {
		return address_remarks;
	}

	/**
	 * @param address_remarks the address_remarks to set
	 */
	public void setAddress_remarks(String address_remarks) {
		this.address_remarks = address_remarks;
	}
}

