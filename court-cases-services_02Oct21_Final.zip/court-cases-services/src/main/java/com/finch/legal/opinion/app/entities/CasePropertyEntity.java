package com.finch.legal.opinion.app.entities;

import javax.persistence.Column;
/**
 * department entity
 * @author finch
 *
 */
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "case_property")
public class CasePropertyEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	/** id **/
	private int id;
	
	@Column(name = "prop_id")
	/** employee id **/
	private int prop_id;
	
	
	@Column(name = "bda_case_id")
	/** employee id **/
	private String bda_case_id;


	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}


	/**
	 * @return the prop_id
	 */
	public int getProp_id() {
		return prop_id;
	}


	/**
	 * @param prop_id the prop_id to set
	 */
	public void setProp_id(int prop_id) {
		this.prop_id = prop_id;
	}


	/**
	 * @return the bda_case_id
	 */
	public String getBda_case_id() {
		return bda_case_id;
	}


	/**
	 * @param bda_case_id the bda_case_id to set
	 */
	public void setBda_case_id(String bda_case_id) {
		this.bda_case_id = bda_case_id;
	}

}

