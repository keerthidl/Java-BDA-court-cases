package com.finch.legal.opinion.app.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.finch.legal.opinion.app.entities.CasePropertyEntity;



public interface CasePropertyRepository extends JpaRepository<CasePropertyEntity, Integer> {
	CasePropertyEntity findById(int id);
	
	@Query(value="SELECT * FROM case_property  WHERE bda_case_id=?1",nativeQuery = true)
	List<CasePropertyEntity> findByRecordId(String recordId);
}
