package com.finch.legal.opinion.app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.finch.legal.opinion.app.entities.PropertyAddressEntity;
import com.finch.legal.opinion.app.entities.PropertyEntity;



public interface PropertyRepository extends JpaRepository<PropertyEntity, Integer> {
	PropertyEntity findById(int id);
}
