package com.finch.legal.opinion.app.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.finch.legal.opinion.app.entities.PropertyAddressEntity;
import com.finch.legal.opinion.app.entities.PropertyEntity;
import com.finch.legal.opinion.app.repositories.PropertyRepository;

/**
 * 
 * @author finch
 *
 */

@Service
public class PropertyService {

	 /** employee repository **/
	@Autowired
	private PropertyRepository propertyRepository;
	
	/**
	 * is employee exists
	 */
	public PropertyEntity getPropertyEntity(String id) {
		
	
		
		if(id!=null && id.trim().length()>0) {
			return propertyRepository.findById(Integer.parseInt(id));
		}else {
			return new PropertyEntity();
		}
		
	}
	
	/**
	 * is employee exists
	 */
	public PropertyEntity save(PropertyEntity propertyEntity) {
		
	
		
		if(propertyEntity!=null) {
			return propertyRepository.save(propertyEntity);
		}else {
			return new PropertyEntity();
		}
		
	}
	
	/**
	 * is employee exists
	 */
	public PropertyEntity update(PropertyEntity propertyEntity) {
		
	
		
		if(propertyEntity!=null) {
			return propertyRepository.save(propertyEntity);
		}else {
			return new PropertyEntity();
		}
		
	}
	
}
