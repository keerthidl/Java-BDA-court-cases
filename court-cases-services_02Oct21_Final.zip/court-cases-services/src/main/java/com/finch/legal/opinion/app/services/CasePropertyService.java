package com.finch.legal.opinion.app.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.finch.legal.opinion.app.entities.CasePropertyEntity;
import com.finch.legal.opinion.app.repositories.CasePropertyRepository;

/**
 * 
 * @author finch
 *
 */

@Service
public class CasePropertyService {

	 /** employee repository **/
	@Autowired
	private CasePropertyRepository casePropertyRepository;
	
	/**
	 * is employee exists
	 */
	public CasePropertyEntity getCasePropertyEntity(String id) {
		

		if(id!=null && id.trim().length()>0) {
			return casePropertyRepository.findById(Integer.parseInt(id));
		}else {
			return new CasePropertyEntity();
		}
		
	}
	
	
	/**
	 * is employee exists
	 */
	public List<CasePropertyEntity> getPropertyId(String recordId) {
		

		if(recordId!=null && recordId.trim().length()>0) {
			return casePropertyRepository.findByRecordId(recordId);
		}else {
			return null;
		}
		
	}
	
	/**
	 * is employee exists
	 */
	public CasePropertyEntity save(CasePropertyEntity casePropertyEntity) {
		

		if(casePropertyEntity!=null) {
			return casePropertyRepository.save(casePropertyEntity);
		}else {
			return new CasePropertyEntity();
		}
		
	}
	
	/**
	 * is employee exists
	 */
	public CasePropertyEntity update(CasePropertyEntity casePropertyEntity) {
		

		if(casePropertyEntity!=null) {
			return casePropertyRepository.save(casePropertyEntity);
		}else {
			return new CasePropertyEntity();
		}
		
	}
}
