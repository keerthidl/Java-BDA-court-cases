package com.finch.legal.opinion.app.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.finch.legal.opinion.app.entities.AdvocatesEntity;
import com.finch.legal.opinion.app.entities.PropertyAddressEntity;
import com.finch.legal.opinion.app.repositories.AdvocatesRepository;
import com.finch.legal.opinion.app.repositories.PropertyAddressRepository;

import jdk.internal.org.jline.utils.Log;

/**
 * 
 * @author finch
 *
 */

@Service
public class PropertyAddressService {

	 /** employee repository **/
	@Autowired
	private PropertyAddressRepository propertyAddressRepository;
	
	/**
	 * is employee exists
	 */
	public PropertyAddressEntity getPropertyAddresssEntity(String id) {
		
	
		
		if(id!=null && id.trim().length()>0) {
			return propertyAddressRepository.findById(Integer.parseInt(id));
		}else {
			return new PropertyAddressEntity();
		}
		
	}
	
	/**
	 * is employee exists
	 */
	public PropertyAddressEntity getPropertyAddresssEntityByName(String name) {
		
	
		
		if(name!=null && name.trim().length()>0) {
			return propertyAddressRepository.findByName(name);
		}else {
			return null;
		}
		
	}
	
	/**
	 * is employee exists
	 */
	public PropertyAddressEntity save(PropertyAddressEntity propertyAddressEntity) {
		
		System.out.println(" 000000000000000000 SAVVVVVVVVVVVVVVVVVVVVVVVVVV    "+propertyAddressEntity);
		
		if(propertyAddressEntity!=null) {
			System.out.println(" SAVVVVVVVVVVVVVVVVVVVVVVVVVV mmmmm    "+propertyAddressEntity);
			return propertyAddressRepository.save(propertyAddressEntity);
		}else {
			return new PropertyAddressEntity();
		}
		
	}
	
	/**
	 * is employee exists
	 */
	public PropertyAddressEntity update(PropertyAddressEntity propertyAddressEntity) {
		
	
		
		if(propertyAddressEntity!=null) {
			return propertyAddressRepository.save(propertyAddressEntity);
		}else {
			return new PropertyAddressEntity();
		}
		
	}
}
