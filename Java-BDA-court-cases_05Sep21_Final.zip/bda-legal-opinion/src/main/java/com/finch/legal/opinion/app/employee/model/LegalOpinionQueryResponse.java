package com.finch.legal.opinion.app.employee.model;

/**
 * 
 * @author finch
 *
 */
public class LegalOpinionQueryResponse extends BaseResponse{

	
	/**
	 * default constructor
	 */
	public LegalOpinionQueryResponse() {
		
	}
}
