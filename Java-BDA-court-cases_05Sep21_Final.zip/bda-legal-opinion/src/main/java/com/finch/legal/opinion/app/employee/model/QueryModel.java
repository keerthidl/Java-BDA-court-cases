package com.finch.legal.opinion.app.employee.model;

/**
 * 
 * @author finch
 *
 */
public class QueryModel {

	/**
	 * query model
	 */
	public final String QUERY;
	
	/**
	 * default constructor
	 */
	public QueryModel(String strQuery) {
		this.QUERY = strQuery;
	}
	
	/**
	 * test
	 */
	public static String getQuery() {
		return "";
	}
}
